#!/bin/bash

cd /Users/bensu/Desktop/usecases 
java -jar WordToFeature.jar "/Users/bensu/Documents/measure_project/src/test/resources/stepdefinations/hornetnestbasicusecase.docx"

sleep 5
cd /Users/bensu/Documents/measure_project
mvn verify
