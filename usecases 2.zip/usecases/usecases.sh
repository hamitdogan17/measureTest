#!/bin/bash

cd /Users/bensu/Desktop/usecases 
java -jar WordToFeature.jar "/Users/bensu/Documents/measure_project/src/test/resources/stepdefinations/hornetnestbasicusecase.docx"

sleep 3
cd /Users/bensu/Documents/measure_project
mvn verify
